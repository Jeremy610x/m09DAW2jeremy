<?php
require_once '307Persona.php';


class Empleado extends Persona {
    private  int $sueldo;
    private array $telefonos = [];

    public function __construct(string $nombre, string $apellidos, int $sueldo) {
        parent::__construct($nombre, $apellidos);
        $this->sueldo = $sueldo;
    }

    public function getSueldo(): int {
        return $this->sueldo;
    }

    public function setSueldo(int $sueldo): void {
        $this->sueldo = $sueldo;
    }

    public function debePagarImpuestos(): bool {
        return $this->sueldo > 3333;
    }

    public function anyadirTelefono(int $telefono): void {
        $this->telefonos[] = $telefono;
    }

    public function listarTelefonos(): string {
        return implode(", ", $this->telefonos);
    }

    public function vaciarTelefonos(): void {
        $this->telefonos = [];
    }

    public static function toHtml(Empleado $empleado): string {
        $html = "<p>Nombre completo: " . htmlspecialchars($empleado->getNombreCompleto()) . "</p>";
        $html .= "<p>Sueldo: " . htmlspecialchars((string) $empleado->getSueldo()) . " euros </p>";
        $html .= "<p>Debe pagar impuestos: " . ($empleado->debePagarImpuestos() ? "si" : "no") . "</p>";
        $html .= "<ol>";
        foreach ($empleado->telefonos as $telefono) {
            $html .= "<li>" . htmlspecialchars((string) $telefono) . "</li>";
        }
        $html .= "</ol>";

        return $html;
    }
  }

?>
