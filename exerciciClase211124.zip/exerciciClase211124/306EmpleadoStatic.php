<?php
class EmpleadoSueldo {
private string $nombre;
private string $apellidos;
private int $sueldo;
private array $telefonos = [];
private static int $sueldoTope = 100000;
const IMPUESTOS = 0.21;

public function __construct(string $nom=null, $apell=null, $suel=1000, $tel=null) {
$this->nombre = $nom;
$this->apellidos = $apell;
$this->sueldo = $suel;
$this->telefonos[] = $tel;
}
public function setSueldo(int $suel) {
$this->sueldo = $suel;
}
public static function setSueldoTope(int $suel) {
self::$sueldoTope = $suel;
}
public function getNombre() {
return $this->nombre;
}
public function getApellidos() {
return $this->apellidos;
}
public function getSueldos() {
return $this->sueldo;
}
public static function getSueldoTope():int {
return self::$sueldoTope;
}
public function getNombreCompleto() {
return $this->nombre . " " . $this->apellidos;
}
public function debePagarImpuestos() {
return ($this->sueldo > 3333);
}
public function anyadirTelefono(int $tel) {
$this->telefonos[] = $tel;
}
public function listarTelefonos() {
$cadena = "";
foreach ($this->telefonos as $telefono) {
$cadena .= $telefono . ", ";
}
return $cadena;
}
public function vaciarTelefonos() {
$this->telefonos = [];
}
public function sueldoConImpuestos() {
if ($this->sueldo >= self::$sueldoTope) {
$this->sueldo -= ($this->sueldo * self::IMPUESTOS);
}
return $this->sueldo;
}

//Copia la clase del ejercicio anterior y modifícala. 
//Completa el siguiente método con una cadena HTML que muestre los datos
 //de un empleado dentro de un párrafo
  //y todos los teléfonos mediante una
  // lista ordenada (para ello, deberás crear un getter para los teléfonos):



  public static function toHtml(EmpleadoSueldo $emp): string{
    
    $html = "<p>Nombre Completo : " . htmlspecialchars($emp->getNombreCompleto())."</p>";
    $html = "<p>Sueldo : " . htmlspecialchars((string) $emp->getSueldos()) . " euros </p>";
    $html .= "<p>Debe pagar impuestos: " . ($emp->debePagarImpuestos() ? "si" : "no") . "</p>";
    $html .= "<ol>";
    foreach ($emp->telefonos as $telefono) {
        $html .= "<li>" . htmlspecialchars((string) $telefono) . "</li>";
    }
    $html .= "</ol>";

    return $html;
}

  }






?>
